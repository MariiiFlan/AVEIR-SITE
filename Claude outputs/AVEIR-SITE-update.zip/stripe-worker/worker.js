const FEE_RATE = 0.025;
const DEFAULT_STORE_URL = 'https://aveir.us';
const ALLOWED_ORIGINS = ['https://aveir.us', 'https://www.aveir.us', 'https://mariiiflan.github.io'];
const SIZES = ['S', 'M', 'L', 'XL', '2XL'];
const MAX_QTY = 20;

function originOf(url) {
  try { return new URL(url).origin; } catch (e) { return ''; }
}

function cors(res, origin) {
  res.headers.set('Access-Control-Allow-Origin', ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0]);
  res.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.headers.set('Access-Control-Allow-Headers', 'Content-Type');
  res.headers.set('Vary', 'Origin');
  return res;
}

function json(body, status, origin) {
  return cors(Response.json(body, { status: status || 200 }), origin);
}

async function loadStore(env) {
  const base = env.STORE_URL || DEFAULT_STORE_URL;
  const r = await fetch(base + '/catalog.js', { cf: { cacheTtl: 60, cacheEverything: true } });
  if (!r.ok) throw new Error('catalog unavailable');
  const text = await r.text();
  const m = text.match(/AVEIR_STORE\s*=\s*(\{[\s\S]*?\});/);
  if (!m) throw new Error('catalog unreadable');
  return JSON.parse(m[1]);
}

async function stripe(env, method, path, params) {
  const r = await fetch('https://api.stripe.com/v1/' + path, {
    method,
    headers: {
      'Authorization': 'Bearer ' + env.STRIPE_SECRET_KEY,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: params ? params : undefined
  });
  return r.json();
}

function countryCode(v) {
  const c = String(v || '').trim().toUpperCase();
  if (!c || ['US', 'USA', 'UNITED STATES', 'UNITED STATES OF AMERICA'].includes(c)) return 'US';
  if (/^[A-Z]{2}$/.test(c)) return c;
  return '';
}

async function createSession(request, env, origin) {
  let b;
  try { b = await request.json(); } catch (e) { return json({ error: 'bad request' }, 400, origin); }
  if (!Array.isArray(b.items) || !b.items.length || b.items.length > 30) return json({ error: 'no items' }, 400, origin);
  if (!ALLOWED_ORIGINS.includes(originOf(b.success_url)) || !ALLOWED_ORIGINS.includes(originOf(b.cancel_url))) return json({ error: 'bad return url' }, 400, origin);

  let store;
  try { store = await loadStore(env); } catch (e) { return json({ error: 'store unavailable' }, 502, origin); }
  const bySlug = {};
  (store.catalog || []).forEach(p => { bySlug[p.slug] = p; });
  const promos = store.promos || {};
  const code = String(b.promo || '').trim().toUpperCase();
  const rate = promos[code] || 0;

  const p = new URLSearchParams();
  p.set('mode', 'payment');
  p.set('success_url', b.success_url);
  p.set('cancel_url', b.cancel_url);
  if (b.email && String(b.email).indexOf('@') > 0) p.set('customer_email', String(b.email).slice(0, 200));

  let i = 0, subC = 0, afterC = 0;
  const summary = [];
  for (const it of b.items) {
    const prod = bySlug[it.slug];
    if (!prod) return json({ error: 'unknown item' }, 400, origin);
    const qty = Math.round(Number(it.qty));
    if (!(qty >= 1 && qty <= MAX_QTY)) return json({ error: 'bad quantity' }, 400, origin);
    const size = SIZES.includes(String(it.size).toUpperCase()) ? String(it.size).toUpperCase() : '';
    const color = String(it.color || '').toLowerCase().replace(/[^a-z]/g, '').slice(0, 20);
    const unit = Math.round(prod.price * 100);
    const unitAfter = Math.round(prod.price * 100 * (1 - rate));
    subC += unit * qty;
    afterC += unitAfter * qty;
    const label = prod.name + (size || color ? ' (' + [size, color.toUpperCase()].filter(Boolean).join(' / ') + ')' : '');
    summary.push(label + ' x' + qty);
    p.set(`line_items[${i}][quantity]`, String(qty));
    p.set(`line_items[${i}][price_data][currency]`, 'usd');
    p.set(`line_items[${i}][price_data][unit_amount]`, String(unitAfter));
    p.set(`line_items[${i}][price_data][product_data][name]`, (label + (rate ? ' - ' + code : '')).slice(0, 120));
    i++;
  }

  const ships = store.shipping || [];
  const ship = ships.find(o => o.id === b.ship) || ships[0];
  if (!ship) return json({ error: 'no shipping' }, 400, origin);
  const freeOver = store.freeShippingOver ?? 100;
  const shipC = (ship.id === 'std' && subC >= freeOver * 100) ? 0 : Math.round(ship.price * 100);
  const addr = b.address || {};
  const st = String(addr.state || '').trim().toUpperCase();
  const taxes = store.tax || {};
  const taxRate = taxes[st] ?? taxes.default ?? 0;
  const taxC = Math.round(afterC * taxRate);

  for (const extra of [['SHIPPING - ' + ship.name, shipC], ['SALES TAX', taxC]]) {
    if (extra[1] > 0) {
      p.set(`line_items[${i}][quantity]`, '1');
      p.set(`line_items[${i}][price_data][currency]`, 'usd');
      p.set(`line_items[${i}][price_data][unit_amount]`, String(extra[1]));
      p.set(`line_items[${i}][price_data][product_data][name]`, extra[0]);
      i++;
    }
  }

  const total = afterC + shipC + taxC;
  p.set('payment_intent_data[application_fee_amount]', String(Math.round(total * FEE_RATE)));
  p.set('payment_intent_data[transfer_data][destination]', env.CONNECTED_ACCOUNT_ID);

  const name = String(b.name || '').slice(0, 100);
  const cc = countryCode(addr.country);
  if (name && addr.line1 && cc) {
    p.set('payment_intent_data[shipping][name]', name);
    if (b.phone) p.set('payment_intent_data[shipping][phone]', String(b.phone).slice(0, 30));
    p.set('payment_intent_data[shipping][address][line1]', String(addr.line1).slice(0, 200));
    if (addr.line2) p.set('payment_intent_data[shipping][address][line2]', String(addr.line2).slice(0, 200));
    p.set('payment_intent_data[shipping][address][city]', String(addr.city || '').slice(0, 100));
    p.set('payment_intent_data[shipping][address][state]', st.slice(0, 50));
    p.set('payment_intent_data[shipping][address][postal_code]', String(addr.postal_code || '').slice(0, 20));
    p.set('payment_intent_data[shipping][address][country]', cc);
  }
  const meta = { items: summary.join(' | ').slice(0, 500), shipping: ship.name, promo: code && rate ? code : '', state: st };
  for (const k in meta) {
    p.set(`metadata[${k}]`, meta[k]);
    p.set(`payment_intent_data[metadata][${k}]`, meta[k]);
  }

  const j = await stripe(env, 'POST', 'checkout/sessions', p);
  if (j.error) return json({ error: j.error.message }, 400, origin);
  return json({ url: j.url }, 200, origin);
}

async function verifySession(url, env, origin) {
  const id = url.searchParams.get('session_id') || '';
  if (!/^cs_[A-Za-z0-9_]+$/.test(id)) return json({ paid: false }, 400, origin);
  const j = await stripe(env, 'GET', 'checkout/sessions/' + id);
  if (j.error) return json({ paid: false }, 404, origin);
  return json({
    paid: j.payment_status === 'paid',
    total: (j.amount_total || 0) / 100,
    payment: j.payment_intent || id
  }, 200, origin);
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    if (request.method === 'OPTIONS') return cors(new Response(null, { status: 204 }), origin);
    if (origin && !ALLOWED_ORIGINS.includes(origin)) return json({ error: 'forbidden' }, 403, origin);
    const url = new URL(request.url);
    if (request.method === 'GET') return verifySession(url, env, origin);
    if (request.method === 'POST') return createSession(request, env, origin);
    return json({ error: 'method not allowed' }, 405, origin);
  }
};
